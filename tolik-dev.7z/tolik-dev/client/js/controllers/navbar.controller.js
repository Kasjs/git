angular.module('rssreader').controller('NavbarController', ['$scope', '$state','$auth', function ($scope, $state, $auth) {
    $scope.isLoggedIn = function(){
		return $auth.isAuthenticated();
	} 
    $scope.currentUser = function(){
		return $auth.getPayload().userId
	}  
    $scope.logOut = function () {
        $auth.logout();
        $state.go("home");
    }
    $scope.goHome = function () {
        if ($scope.isLoggedIn()) {
            $state.go("dashboard");
        }
        else{
            $state.go("home");
        }
    }
}]);