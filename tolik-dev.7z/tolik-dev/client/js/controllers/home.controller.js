angular.module('rssreader').controller('HomeController', ['$scope', '$state', 'dashboardService', 'feedsService', '$auth' , function ($scope, $state , dashboardService, feedsService, $auth) {
    $scope.isLoggedIn = function() {
		return $auth.isAuthenticated();
		console.log($auth);
	}
    $scope.currentUser = function() {
		return $auth.getPayload().userId;	
	} 

    $scope.OnFeeds = function () {
        if ($scope.isLoggedIn()) {
            $state.go('dashboard.' + dashboardService.currentView, {
                id: $scope.currentUser()
            });
        } else {
            alert('Unauthtorized');
        }
    }
    $scope.OnRegister = function () {
        $state.go('register');
    }
    $scope.OnLogin = function () {
        $state.go('login');
    }
}]);