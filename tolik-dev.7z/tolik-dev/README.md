# Ch-041 Development branch

1. Install node
2. Install MongoDB
3. Add MongoDB 'mongod' command as PATH variable (https://www.youtube.com/watch?v=sBdaRlgb4N8&feature=youtu.be&t=120)
4. Create folder for DB temp files in the root (projectRoot\data)
5. Run 'npm start'
6. Visit 'localhost:8080'
